<?php
namespace App\Repository\{replace};

interface {replace}Interface
{

}
