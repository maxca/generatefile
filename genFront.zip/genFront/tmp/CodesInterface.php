<?php
namespace App\Repository\Codes;

interface CodesInterface
{

}
